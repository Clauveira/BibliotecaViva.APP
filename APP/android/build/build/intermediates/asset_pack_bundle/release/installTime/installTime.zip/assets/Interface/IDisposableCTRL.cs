namespace BibliotecaViva.CTRL.Interface
{
    public interface IDisposableCTRL
    {
        void FecharCTRL();
    }
}